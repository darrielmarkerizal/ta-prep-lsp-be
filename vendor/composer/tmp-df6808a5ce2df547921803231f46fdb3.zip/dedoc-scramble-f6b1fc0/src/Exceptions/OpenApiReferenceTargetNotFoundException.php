<?php

namespace Dedoc\Scramble\Exceptions;

class OpenApiReferenceTargetNotFoundException extends \Exception {}
