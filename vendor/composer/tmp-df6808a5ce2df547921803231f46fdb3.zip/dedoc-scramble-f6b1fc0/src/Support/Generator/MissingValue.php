<?php

namespace Dedoc\Scramble\Support\Generator;

class MissingValue {}
