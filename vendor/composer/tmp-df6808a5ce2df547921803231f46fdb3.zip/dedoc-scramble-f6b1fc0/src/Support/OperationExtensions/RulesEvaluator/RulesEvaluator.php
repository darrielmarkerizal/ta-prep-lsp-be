<?php

namespace Dedoc\Scramble\Support\OperationExtensions\RulesEvaluator;

interface RulesEvaluator
{
    public function handle(): array;
}
