<?php

namespace Dedoc\Scramble\Attributes;

class MissingValue {}
