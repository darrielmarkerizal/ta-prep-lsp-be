<?php

namespace Nwidart\Modules\Contracts;

interface ConfirmableCommand {}
