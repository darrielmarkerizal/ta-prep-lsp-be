---
name: "🐛 Bug Report"
about: 'Report a general bug.'
labels: bug

---

### Versions:
- laravel-modules Version: #.#.#
- Laravel Version: #.#.#
- PHP Version: #.#.#

### Description:

<!--
Please describe in detail the nature of the bug, code samples, etc.

The more, the better.
-->

### Steps To Reproduce:

- …
