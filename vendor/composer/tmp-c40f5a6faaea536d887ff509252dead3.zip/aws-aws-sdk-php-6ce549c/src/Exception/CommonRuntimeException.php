<?php
namespace Aws\Exception;

class CommonRuntimeException extends \RuntimeException
{
    
}
